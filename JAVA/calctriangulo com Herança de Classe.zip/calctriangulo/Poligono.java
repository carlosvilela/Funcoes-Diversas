package calctriangulo;

public class Poligono {


    private String cor;
    
    public void setCor(String Color){
        
        this.cor = Color;
        
        
    }
    
    public String getCor(){
        return (this.cor);
    }



    
}

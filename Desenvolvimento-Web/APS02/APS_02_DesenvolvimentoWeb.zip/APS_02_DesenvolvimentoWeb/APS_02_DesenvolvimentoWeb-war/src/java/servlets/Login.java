/*
||==========================================================================||
||               APS 02 - Desenvolvimento de Aplicações Web                 ||
|| Aluno: Carlos Bezerra Vilela                                             ||
|| Turma: 136; Unidade: Rio Comprido;                                       ||
||==========================================================================||
*/

package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "Login", urlPatterns = {"/Login", "/login"})
public class Login extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String site = "https://www.unicarioca.edu.br/";
        
        String user;
        String pass;
        
        user = request.getParameter("user");
        pass = request.getParameter("pass");
        
        
        if(user.equals("Maria") && pass.equals("Maria123")){
            response.sendRedirect(site);
        }else{
        
        
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Login</title>");
            out.println("<meta charset=\"UTF-8\">");
            out.println("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">");
            out.println("<link rel=\"stylesheet\" href=\"css/style.css\" type=\"text/css\"/>");
            out.println("</head>");
            out.println("<body>");
            out.println("<p class=\"servlets\"><h1 class=\"servlets\">Presado Usuário <b>"+user+"</b></h1></p>");
            out.println("<p class=\"servlets\"><h1 class=\"servlets\">O nome de Usuário (<b>"+user+"</b>) ou senha estão incorretos. Tente novamente.</h1></p>");
            out.println("<p class=\"servlets\"><h1 class=\"servlets\"><a href=\"index.html\"><img src=\"imagens/voltar.png\" alt=\"<< VOLTAR AO LOGIN\"></a></h1></p>");
            out.println("</body>");
            out.println("</html>");
        }
        }
    }


}
